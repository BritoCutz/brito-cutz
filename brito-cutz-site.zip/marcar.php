<?php
$nome = $_POST['nome'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];
$datahora = $_POST['datahora'];

$dataFormatada = date("Y-m-d H:00:00", strtotime($datahora));
$arquivo = 'reservas.txt';

$reservas = file_exists($arquivo) ? file($arquivo, FILE_IGNORE_NEW_LINES) : [];

foreach ($reservas as $reserva) {
    list($dataReservada) = explode('|', $reserva);
    if (trim($dataReservada) == $dataFormatada) {
        die("Horário já reservado. Por favor escolha outro.");
    }
}

file_put_contents($arquivo, "$dataFormatada|$nome|$email|$telefone\n", FILE_APPEND);

$assunto = "Confirmação da sua marcação na Brito Cutz";
$mensagem = "Olá $nome,\n\nA tua marcação está confirmada para: $dataFormatada\n\nObrigado,\nBrito Cutz";
$cabecalhos = "From: reservas@teusite.com";

mail($email, $assunto, $mensagem, $cabecalhos);

echo "Reserva feita com sucesso. Verifique seu email!";
?>